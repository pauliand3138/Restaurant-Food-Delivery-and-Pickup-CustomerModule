package com.example.capstoneproject.Common;

import com.example.capstoneproject.Model.Customer;

public class Common {

    public static Customer currentUser;
}
